function retval = partition (x)
	retval = [x(1:(length(x)-1));x(2:length(x))] ;
end
